<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class csv extends Model
{
    protected $primaryKey = 'csv_id';
    public $timestamps = false;
}
